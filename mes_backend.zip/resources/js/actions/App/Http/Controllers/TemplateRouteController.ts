import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TemplateRouteController::index
* @see app/Http/Controllers/TemplateRouteController.php:24
* @route '/api/v1/template-routes'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/template-routes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TemplateRouteController::index
* @see app/Http/Controllers/TemplateRouteController.php:24
* @route '/api/v1/template-routes'
*/
index.url = (options?: RouteQueryOptions) => {




    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TemplateRouteController::index
* @see app/Http/Controllers/TemplateRouteController.php:24
* @route '/api/v1/template-routes'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::index
* @see app/Http/Controllers/TemplateRouteController.php:24
* @route '/api/v1/template-routes'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::index
* @see app/Http/Controllers/TemplateRouteController.php:24
* @route '/api/v1/template-routes'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::index
* @see app/Http/Controllers/TemplateRouteController.php:24
* @route '/api/v1/template-routes'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::index
* @see app/Http/Controllers/TemplateRouteController.php:24
* @route '/api/v1/template-routes'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\TemplateRouteController::store
* @see app/Http/Controllers/TemplateRouteController.php:40
* @route '/api/v1/template-routes'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/template-routes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TemplateRouteController::store
* @see app/Http/Controllers/TemplateRouteController.php:40
* @route '/api/v1/template-routes'
*/
store.url = (options?: RouteQueryOptions) => {




    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TemplateRouteController::store
* @see app/Http/Controllers/TemplateRouteController.php:40
* @route '/api/v1/template-routes'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::store
* @see app/Http/Controllers/TemplateRouteController.php:40
* @route '/api/v1/template-routes'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::store
* @see app/Http/Controllers/TemplateRouteController.php:40
* @route '/api/v1/template-routes'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\TemplateRouteController::show
* @see app/Http/Controllers/TemplateRouteController.php:53
* @route '/api/v1/template-routes/{id}'
*/
export const show = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/template-routes/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TemplateRouteController::show
* @see app/Http/Controllers/TemplateRouteController.php:53
* @route '/api/v1/template-routes/{id}'
*/
show.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }


    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)


    const parsedArgs = {
        id: args.id,
    }

    return show.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TemplateRouteController::show
* @see app/Http/Controllers/TemplateRouteController.php:53
* @route '/api/v1/template-routes/{id}'
*/
show.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::show
* @see app/Http/Controllers/TemplateRouteController.php:53
* @route '/api/v1/template-routes/{id}'
*/
show.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::show
* @see app/Http/Controllers/TemplateRouteController.php:53
* @route '/api/v1/template-routes/{id}'
*/
const showForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::show
* @see app/Http/Controllers/TemplateRouteController.php:53
* @route '/api/v1/template-routes/{id}'
*/
showForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::show
* @see app/Http/Controllers/TemplateRouteController.php:53
* @route '/api/v1/template-routes/{id}'
*/
showForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\TemplateRouteController::update
* @see app/Http/Controllers/TemplateRouteController.php:64
* @route '/api/v1/template-routes/{id}'
*/
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/v1/template-routes/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\TemplateRouteController::update
* @see app/Http/Controllers/TemplateRouteController.php:64
* @route '/api/v1/template-routes/{id}'
*/
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }


    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)


    const parsedArgs = {
        id: args.id,
    }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TemplateRouteController::update
* @see app/Http/Controllers/TemplateRouteController.php:64
* @route '/api/v1/template-routes/{id}'
*/
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::update
* @see app/Http/Controllers/TemplateRouteController.php:64
* @route '/api/v1/template-routes/{id}'
*/
const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::update
* @see app/Http/Controllers/TemplateRouteController.php:64
* @route '/api/v1/template-routes/{id}'
*/
updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\TemplateRouteController::destroy
* @see app/Http/Controllers/TemplateRouteController.php:79
* @route '/api/v1/template-routes/{id}'
*/
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/v1/template-routes/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TemplateRouteController::destroy
* @see app/Http/Controllers/TemplateRouteController.php:79
* @route '/api/v1/template-routes/{id}'
*/
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }


    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)


    const parsedArgs = {
        id: args.id,
    }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TemplateRouteController::destroy
* @see app/Http/Controllers/TemplateRouteController.php:79
* @route '/api/v1/template-routes/{id}'
*/
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::destroy
* @see app/Http/Controllers/TemplateRouteController.php:79
* @route '/api/v1/template-routes/{id}'
*/
const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TemplateRouteController::destroy
* @see app/Http/Controllers/TemplateRouteController.php:79
* @route '/api/v1/template-routes/{id}'
*/
destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const TemplateRouteController = { index, store, show, update, destroy }

export default TemplateRouteController