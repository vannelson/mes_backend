import AuthController from './AuthController'
import UserController from './UserController'
import CustomerController from './CustomerController'
import WorkOrderController from './WorkOrderController'
import TemplateRouteController from './TemplateRouteController'
import Settings from './Settings'


const Controllers = {
    AuthController: Object.assign(AuthController, AuthController),
    UserController: Object.assign(UserController, UserController),
    CustomerController: Object.assign(CustomerController, CustomerController),
    WorkOrderController: Object.assign(WorkOrderController, WorkOrderController),
    TemplateRouteController: Object.assign(TemplateRouteController, TemplateRouteController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers